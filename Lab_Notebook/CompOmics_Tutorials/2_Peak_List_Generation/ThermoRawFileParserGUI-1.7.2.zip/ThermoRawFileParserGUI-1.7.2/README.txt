

   ========================
    ThermoRawFileParserGUI
   ========================

   To start ThermoRawFileParserGUI simply double click the jar file.

   From the command line use 'java -jar ThermoRawFileParserGUI-X.Y.Z.jar'.
   (Replace X.Y.Z with the ThermoRawFileParserGUIversion number.)

   For help with runnng ThermoRawFileParserGUI please see:
   https://github.com/compomics/ThermoRawFileParserGUI


   =================================
    ThermoRawFileParserGUI Web Page
   =================================

   For updated information about ThermoRawFileParserGUI please visit:
   https://github.com/compomics/ThermoRawFileParserGUI

